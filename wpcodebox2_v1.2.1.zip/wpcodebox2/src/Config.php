<?php

namespace Wpcb2;


class Config
{

}
