<?php

namespace Wpcb2\FunctionalityPlugin;


class PluginsFolderNotWritableException extends \Exception
{

}
