<?php

die();